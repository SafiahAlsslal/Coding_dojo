import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from './../http.service';
@Component({
  selector: 'app-burbank',
  templateUrl: './burbank.component.html',
  styleUrls: ['./burbank.component.css']
})
export class BurbankComponent implements OnInit {
  humidity:number
  temp:number;
  temp_max:number;
  temp_min:number;
  status:string;

  constructor( private _httpservice : HttpService ) { }

  ngOnInit() {
    let observable = this._httpservice.getWeather('burbank')
    observable.subscribe((data:any) => {
      console.log("Got weather!", data)
      this.humidity= data.main.humidity;
      this.temp_max= data.main.temp_max;
      this.temp= data.main.temp;
      this.temp_min= data.main.temp_min;
      this.status=data.weather[0].description;
   });
  }

}
