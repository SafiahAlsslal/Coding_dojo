import { Component, OnInit } from '@angular/core';
import { HttpService } from './../http.service';

@Component({
  selector: 'app-san-jose',
  templateUrl: './san-jose.component.html',
  styleUrls: ['./san-jose.component.css']
})
export class SanJoseComponent implements OnInit {

  humidity:number
  temp:number;
  temp_max:number;
  temp_min:number;
  status:string;

  constructor( private _httpservice : HttpService ) { }

  ngOnInit() {
    let observable = this._httpservice.getWeather('san jose')
    observable.subscribe((data:any) => {
      console.log("Got weather!", data)
      this.humidity= data.main.humidity;
      this.temp_max= data.main.temp_max;
      this.temp= data.main.temp;
      this.temp_min= data.main.temp_min;
      this.status=data.weather[0].description;
   });
  }

}
