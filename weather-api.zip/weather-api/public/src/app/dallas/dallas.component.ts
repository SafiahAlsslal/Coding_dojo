import { Component, OnInit } from '@angular/core';
import { HttpService } from './../http.service';

@Component({
  selector: 'app-dallas',
  templateUrl: './dallas.component.html',
  styleUrls: ['./dallas.component.css']
})
export class DallasComponent implements OnInit {

  humidity:number
  temp:number;
  temp_max:number;
  temp_min:number;
  status:string;

  constructor( private _httpservice : HttpService ) { }

  ngOnInit() {
    let observable = this._httpservice.getWeather('dallas')
    observable.subscribe((data:any) => {
      console.log("Got weather!", data)
      this.humidity= data.main.humidity;
      this.temp_max= data.main.temp_max;
      this.temp= data.main.temp;
      this.temp_min= data.main.temp_min;
      this.status=data.weather[0].description;
   });
  }

}
