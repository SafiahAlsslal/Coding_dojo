import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient){
      this.getPokemon();
  }


  getPokemon(){
    let bulbasaur = this._http.get('https://pokeapi.co/api/v2/pokemon/1/');
    bulbasaur.subscribe((data:any) => {
      console.log("Got our pokimon!", data) ;
      console.log(data.name + 's abilities are ' + data.abilities[0].ability.name + " and " + data.abilities[1].ability.name);
      let url1 = data.abilities[1].ability.url;
      let url2 = data.abilities[0].ability.url;
      let pokeimon1 =this._http.get(url1)
      pokeimon1.subscribe((data:any) => {
        console.log(data.pokemon.length + " Pokemon have the overgrow ability.") ;
      });
      let pokeimon2 =this._http.get(url2)
      pokeimon2.subscribe((data:any) => {
        console.log(data.pokemon.length + " Pokemon have the chlorophyll ability.") ;
      });

    }); 
   
}

}
