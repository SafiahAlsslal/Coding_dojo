var mongoose = require('mongoose');
module.exports = {
    user: mongoose.model('user', new mongoose.Schema({
       name: { type: String, required: true, minlength: 6}, },
       {timestamps: true }) ,)
}