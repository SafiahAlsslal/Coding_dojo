// const mongoose = require('mongoose'),
// Users = mongoose.model('user')
// var mod = require('../controllers/users.js')

// module.exports = function(app){
//     // app.get('/', (req, res) => { 
//     //     mod.index(req, res);
//     // });
    
//     // app.get('/new/:name',(req, res) => {
//     //     mod.create(req, res)
//     // })
    
//     // app.get('/remove/:name', (req, res) => {
//     //   mod.remove(req, res);
//     // })
    
//     // app.get('/:name', (req, res) => {
//     //     mod.show(req, res);
//     // })
// }