const express = require("express");
const app = express();
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/first_db', {useNewUrlParser: true});
const AnimalSchema = new mongoose.Schema({
    name: { type: String, required: true, minlength: 6},
    fav_food: { type: String, required: true, minlength: 2} ,
    place: { type: String, required: true, minlength: 5}},
    {timestamps: true });
const Animals = mongoose.model('animals', AnimalSchema);
const session = require('express-session');
app.use(session({
  secret: 'keyboardkitteh',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 60000 }
}))
const flash = require('express-flash');
app.use(flash());
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
const server = app.listen(8000);
app.use(express.urlencoded({extended: true}));


app.get('/', (req, res) => { 
  Animals.find({})
    .then(data => res.render("index", {animals: data}))
    .catch(err => {
      console.log("n1" + err); })
});

app.get( '/animals/:id' , (req, res) => { 
  data1=Animals.findOne({_id: req.params.id})
  .then(data1 => res.render("info", {x: data1}))
  .catch(err => {
    console.log("n2" + err)
    res.redirect('/');
       })
});

app.get( '/animalss/new' , (req, res) => { 
  res.render('new')
});

app.post( '/animals' , (req, res) => { 
  const a = new Animals()
  a.name=req.body.name;
  a.fav_food=req.body.fav_food;
  a.place=req.body.place;
  a.save()
      .then(newAnimal => res.redirect ('/'))
      .catch(err => {
        console.log(err);
        for (var key in err.errors) {
          req.flash('saving', err.errors[key].message);
      }
      res.redirect('/animalss/new');
    });

});

app.get( '/animals/edit/:id' , (req, res) => { 
  data1=Animals.findOne({_id: req.params.id})
    .then(data1 => res.render("edit", {x: data1}))
    .catch(err => {
      console.log("n3" + err)
      for (var key in err.errors) {
        req.flash('update', err.errors[key].message);
      }
      res.redirect('/animalss/new');
         })
});


app.post( '/animals/:id' , (req, res) => { 
   Animals.updateOne({_id: req.params.id},
                    {name: req.body.name,
                    fav_food: req.body.fav_food,
                    place : req.body.place} , { runValidators: true } )
      .then(data => res.redirect('/'))
      .catch(err => {
        console.log("up" + err);
        for (var key in err.errors) {
          req.flash('update', err.errors[key].message);
      }
      res.redirect('/animals/edit/' +req.params.id);
    });

});

app.post( '/animals/destroy/:id' , (req, res) => { 
  Animals.remove({_id: req.params.id})
  .then(data => console.log("RECORD DELETED"))
  .catch(err => {
    console.log("n4" + err); })
    res.redirect('/');
})


