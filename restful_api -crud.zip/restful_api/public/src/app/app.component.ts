import { Component, OnInit  } from '@angular/core';
import { HttpService } from './http.service';
// import { task } from '/';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  tasks= [];
  task=[]
  id=""
  edited : boolean;
  newTask: any;
  updateTask:any;
  constructor(private _httpService: HttpService){ }
  ngOnInit(){
    this.AllTaskClick()
    this.newTask = { title: "", description: "" } 
    this.updateTask= { title: "", description: "" } 
    this.id=""
    this.edited = false;
  }
AllTaskClick(): void{
  console.log(`Click event is working`);
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
       console.log("Got our tasks!", data)
       this.tasks = data['data'];
    });
  }

OneTaskClick(id): void{
  this.edited = true
  this.id=id
  let observable = this._httpService.getOneTask(this.id);
  observable.subscribe((data:any) => {
     console.log("Got our tasks!", data)
    this.updateTask = { title: data.title, description: data.description }
  });   
    }

onSubmit() {
  let observable = this._httpService.addTask(this.newTask);
  observable.subscribe(data => {
    console.log("added sccufully!", data)
 });
  this.newTask = { title: "", description: "" }
  this.AllTaskClick()
}

DeleteTask (id) {
  this.id=id
  console.log(this.id)
  let observable = this._httpService.deleteTask(this.id);
  observable.subscribe(data => {
    console.log("deleted sccufully!")
 });
 this.AllTaskClick()
  this.id=""
}

EditTask () {
  let observable = this._httpService.editTask(this.updateTask , this.id);
  observable.subscribe(data => {
    console.log("updated sccufully!", data)
 });
 this.AllTaskClick()
  this.updateTask = { title: "", description: "" }
  this.id="";
  this.edited = false
}
}
