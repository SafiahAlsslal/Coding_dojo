var mongoose = require('mongoose');
var user = mongoose.model('user');

module.exports = {
    index: function(req, res) {
        user.find ({})
        .then(data => res.json(data))
        .catch(err => {
            console.log("n1"+err);})
    },
    create: function(req, res) {
        const q = new user({name: req.params.name});
        console.log("hi" +req.body.name );
        q.save()
          .then(data => res.redirect('/'))
          .catch(err => {
              console.log("n2"+err);
                res.redirect('/');
          });
    },
    show: function(req, res) {
        user.findOne({name: req.params.name})
        .then(data => res.json(data))
        .catch(err => {
            console.log("n3"+err);})
    },
    remove: function(req, res) {
        user.remove({name: req.params.name})
        .then(res.redirect('/'))
        .catch(err => {
            console.log("n4"+err);
            res.redirect('/') })
    }
};