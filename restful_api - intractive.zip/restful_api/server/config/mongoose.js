const mongoose = require('mongoose');
module.exports = {
   connect: mongoose.connect('mongodb://localhost/s_db', {useNewUrlParser: true})
}

