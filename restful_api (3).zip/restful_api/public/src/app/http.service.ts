import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient){
    console.log("hi"); }

  getTasks(){
    return this._http.get('/tasks');
 }

 getOneTask(task_id) {
    console.log('ID is', task_id);
    return this._http.get('/tasks/'+task_id);
  }
}
