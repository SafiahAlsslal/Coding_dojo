import { Component, OnInit  } from '@angular/core';
import { HttpService } from './http.service';
// import { task } from '/';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  tasks= [];
  y=3
  constructor(private _httpService: HttpService){ }
  ngOnInit(){
    this.getTasksFromService();
  }
  getTasksFromService(){
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
       console.log("Got our tasks!", data)
       this.tasks = data['data'];
       console.log("Got our tasks!2", this.tasks)
    });
  }
}
