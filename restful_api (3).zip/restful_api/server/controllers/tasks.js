var mongoose = require('mongoose');
var task = mongoose.model('task');

module.exports = {
    index: function(req, res) { //all
        task.find ({})
        .then(data => {
             res.json({ message: "Success", data: data }) 
             console.log(data)
        })
        .catch(err => {
            console.log("n1"+err);
            res.json({ message: "Error", error: err });})
    },
    create: function(req, res) { //post task
        const q = new task({
            title: req.paras.title,
            description: req.params.description,
            completed: req.params.completed
        });
      q.save()
          .then(data => res.json({ message: "Success inserted", data: data }))
          .catch(err => {
              console.log("n2"+err);
              res.json({ message: "Error", error: err })
          });
    },
    show: function(req, res) { //retrive one
        task.findOne({id: req.params.id})
        .then(data => res.json(data))
        .catch(err => {
            console.log("n3"+err);
            res.json({ message: "Error", error: err })
        })
    },

    update: function(req, res) { //update one "edit"
    var obje = {};
    if (req.body.title) {
        obje['title'] = req.body.title;
    }
    if (req.body.description) {
        obje['description'] = req.body.description;
    }
    if (req.body.completed != null) {
        obje['completed'] = req.body.completed;
    }
    obje['updated_at'] = Date.now();
    task.update({ _id: req.params.id }, { $set: obj })
        .then(data => res.json(data))
        .catch(err => {
            res.json({ message: "Error", error: err })
            console.log("n3"+err);})
    },

    remove: function(req, res) { //delete
        task.remove({id: req.params.id})
        .then( res.json({ message: "Success"}) )
        .catch(err => {
            console.log("n4"+err);
            res.json({ message: "error"}) })
    }
};