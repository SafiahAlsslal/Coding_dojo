const mongoose = require('mongoose'),
task = mongoose.model('task')
var mod = require('../controllers/tasks.js')

module.exports = function(app){
    app.get('/tasks', (req, res) => { 
        mod.index(req, res);
    });
    
    app.post('/task/:title/:description/:completed',(req, res) => {
        mod.create(req, res)
    })
    
    app.delete('/tasks/:id', (req, res) => {
      mod.remove(req, res);
    })

    app.put('/tasks/:id', (req, res) => {
        mod.update(req, res);
      })
    
    app.get('/tasks/:id', (req, res) => {
        mod.show(req, res);
    })
}