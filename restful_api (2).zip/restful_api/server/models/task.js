var mongoose = require('mongoose');
module.exports = {
    task: mongoose.model('task', new mongoose.Schema({
       title: { type: String, required: true, minlength: 6},
        description: {type: String , default: ""},
        completed: {type: Boolean , default: false}
     },
       {timestamps: true }) ,)
}