import { Component, OnInit  } from '@angular/core';
import { HttpService } from './http.service';
// import { task } from '/';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  tasks= [];
  task=[]
  id=""
  selectedTask=""
  constructor(private _httpService: HttpService){ }
  ngOnInit(){
    this.id="";
    this.selectedTask=""
  }
AllTaskClick(): void{
  console.log(`Click event is working`);
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
       console.log("Got our tasks!", data)
       this.tasks = data['data'];
    });
  }

  OneTaskClick(id): void{
    this.id=id
    let observable = this._httpService.getOneTask(this.id);
    observable.subscribe((data:any) => {
       console.log("Got our tasks!", data) 
       this.selectedTask=data
    });   
      }

}
